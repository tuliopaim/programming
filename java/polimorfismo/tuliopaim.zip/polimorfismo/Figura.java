abstract class Figura implements Desenho{

  abstract double calculaArea();

  abstract double calculaPerimetro();

}
