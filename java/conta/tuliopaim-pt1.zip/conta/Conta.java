class Conta{
  private int numero;
  private String dono;
  private double saldo;

  Conta(){}

  void sacar(double valor){
      this.saldo -= valor;
  }

  void depositar(double valor){
    this.saldo += valor;
  }

  void transferirPara(Conta destino, double valor){
    sacar(valor);
    destino.depositar(valor);
  }


	public int getNumero() {
		return this.numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getDono() {
		return this.dono;
	}

	public void setDono(String dono) {
		this.dono = dono;
	}

	public double getSaldo() {
		return this.saldo;
	}

  public void setSaldo(double saldo){
    this.saldo = saldo;
  }

  public String toString(){
    return "Numero: " + this.numero +
    "\nTitular: " + this.dono +
    "\nSaldo: " + this.saldo;
  }

}
