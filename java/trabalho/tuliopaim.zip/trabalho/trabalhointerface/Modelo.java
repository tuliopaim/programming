package trabalhointerface;
interface Modelo{
  public String TITULO_DO_PROJETO = "Projeto de Ensino";

  public void imprimir();
  public String toString();
}
