class ContaPoupanca extends Conta{

  ContaPoupanca(){
    super();
  }

  void atualizaSaldo(double porcentagem){
      setSaldo(getSaldo() * (1 + (porcentagem/100)));
  }


}
