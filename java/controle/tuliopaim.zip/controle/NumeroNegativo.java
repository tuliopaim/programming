public class NumeroNegativo{
  public NumeroNegativo(String msg){
    super(msg);
  }
}
