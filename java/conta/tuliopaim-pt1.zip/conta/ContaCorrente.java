class ContaCorrente extends Conta{

  ContaCorrente(){
    super();
  }

  void sacar(double valor){
    setSaldo(getSaldo() - valor - 0.05);
  }

  void depositar(double valor){
    setSaldo(getSaldo() + valor - 0.05);
  }


}
