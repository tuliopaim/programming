public interface Desenho{
  public abstract String desenhar();
}
