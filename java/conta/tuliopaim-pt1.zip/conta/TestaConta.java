class TestaConta{
  public static void main(String[] args) {

    ContaCorrente contaC = new ContaCorrente();
    ContaPoupanca contaP = new ContaPoupanca();

    contaC.setDono("Tulio Paim");
    contaC.setNumero(1);
    contaC.setSaldo(5000);

    contaP.setDono("Tulio Paim");
    contaP.setNumero(2);
    contaP.setSaldo(1000);

    contaP.atualizaSaldo(15);
    //System.out.println("Saldo: " + contaP.getSaldo());

    ContaCorrente contaC1 = new ContaCorrente();
    contaC1.depositar(555.04);

    contaP.transferirPara(contaC1, 1000);
    //System.out.println("Saldo: " + contaP.getSaldo());
    //System.out.println("Saldo: " + contaC1.getSaldo());

    ContaSalario salarioTulio = new ContaSalario();
    salarioTulio.depositar(500);
    System.out.println("Saldo Tulio: " + salarioTulio.getSaldo());

    ContaCorrente chefeTulio = new ContaCorrente();
    chefeTulio.setSaldo(500000);
    System.out.println("Saldo chefe: " + chefeTulio.getSaldo());

    chefeTulio.transferirPara(salarioTulio, 15000);
    System.out.println("Saldo chefe: " + chefeTulio.getSaldo());
    System.out.println("Saldo Tulio: " + salarioTulio.getSaldo());


  }
}
